﻿using System;
using Microsoft.Quantum.Simulation.Core;
using Microsoft.Quantum.Simulation.Simulators;

namespace Quantum.QSharpAlgorithmsFinal
{
    class Driver
    {
        static void Main(string[] args)
        {
            using (var qsim = new QuantumSimulator())
            {
                // 1. Create the array of bits that are generated in Operations.qs.
                Result[] bitArray = new Result[16];
             
                string[] stringBitArray = new string[16];
               
                
                
                string temp;
                             

                for (int i = 0; i < 16; i++)
                {
                    
                    bitArray[i] = QuantumRandomNumberGenerator.Run(qsim).Result;

                   
                    temp = bitArray[i].ToString();

                   
                    stringBitArray[i] = temp;

                   
                    if (stringBitArray[i].Equals("Zero"))
                    {
                        stringBitArray[i] = "0";
                    }
                    else
                    {
                        stringBitArray[i] = "1";
                    }

                   
                }                               

                
     
            }
        }
    }
}